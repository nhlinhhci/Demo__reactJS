import logo from './logo.svg';
import './App.css';
import DemoFunction from './Components/DemoComponent/DemoFunction';
import DemoClass from './Components/DemoComponent/DemoClass';
import CardProduct from './Components/DemoComponent/CardProduct';
import BaiTapLayout1 from './Components/BaiTapLayout1/BaiTapLayout1';
import Databinding from './Databinding/Databinding';

function App() {
  return (
    <div className="App">
        {/* <BaiTapLayout1 /> */}
        <Databinding />
    </div>
  );
}

export default App;
